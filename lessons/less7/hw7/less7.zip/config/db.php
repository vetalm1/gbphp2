<?php
	define('DRIVER','mysql');
	define('SERVER', 'localhost:3307');
	define('USERNAME', 'root');
	define('PASSWORD', '');
	define('DB', 'test');
?>