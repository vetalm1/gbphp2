<?php
//define('MY','VALUE');

  CONST PHOTO = './images/';
  CONST PHOTO_SMALL = './img/';
?>
