-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3307
-- Время создания: Окт 17 2019 г., 14:29
-- Версия сервера: 5.6.43
-- Версия PHP: 7.1.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `test`
--

-- --------------------------------------------------------

--
-- Структура таблицы `basket`
--

CREATE TABLE `basket` (
  `id_basket` int(11) NOT NULL,
  `user_name` text NOT NULL,
  `id_good` int(11) NOT NULL,
  `good_name` text NOT NULL,
  `price` int(11) NOT NULL,
  `order_id` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `basket`
--

INSERT INTO `basket` (`id_basket`, `user_name`, `id_good`, `good_name`, `price`, `order_id`) VALUES
(32, 'Vetal', 3, 'Cтул белый', 1200, '69'),
(35, 'Vetal', 1, 'Чаша-толкушка', 500, '69'),
(36, 'Vetal', 2, 'Светильник серый', 1000, '69'),
(39, 'Alena', 4, 'Cветильник черный', 1400, ''),
(40, 'Alena', 1, 'Чаша-толкушка', 500, ''),
(41, 'Elena', 3, 'Cтул белый', 1200, ''),
(42, 'Elena', 6, 'Увлажнитель интерьерный', 2700, ''),
(43, 'Alena', 3, 'Cтул белый', 1200, ''),
(49, 'admin', 5, 'Cветильник черный (ал.)', 700, '66'),
(57, 'admin', 6, 'Увлажнитель интерьерный', 2700, '66'),
(58, 'admin', 6, 'Увлажнитель интерьерный', 2700, '67'),
(61, 'admin', 1, 'Чаша-толкушка', 500, '67'),
(63, 'admin', 4, 'Cветильник черный', 1400, '67'),
(64, 'admin', 3, 'Cтул белый', 1200, '68'),
(65, 'admin', 4, 'Cветильник черный', 1400, '68'),
(66, 'Vetal', 4, 'Cветильник черный', 1400, '69'),
(72, 'Vetal', 10, 'Камень декоративный', 1200, ''),
(85, 'Vetal', 4, 'Cветильник черный', 1400, ''),
(86, 'Vetal', 6, 'Увлажнитель интерьерный', 2700, '');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `basket`
--
ALTER TABLE `basket`
  ADD PRIMARY KEY (`id_basket`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `basket`
--
ALTER TABLE `basket`
  MODIFY `id_basket` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=88;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
