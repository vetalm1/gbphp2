

function getdetails(id, name, price, action, user_name, path){
    console.log('Run');
    $.ajax({
        type: "POST",
        url: path,
        data: {sendId:id, sendName:name, sendPrice:price, sendUser_name:user_name, action:action}
    }).done(function( result )
        {
           $("#msg").html( name+ " - " + result );
           id_button = '#'+id;
           $(id_button).attr('style', 'display:none'); //'class', 'alert-dark'
           $('#summ').attr('style', 'display:none');
        });
}