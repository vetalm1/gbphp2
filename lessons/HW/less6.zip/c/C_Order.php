<?php
// Конттроллер Заказов.
require_once('m/M_Basket.php');
class C_Order extends C_Base
{
	// Конструктор ???.
	
	public function action_getOrder(){
        $this->title .= '::Заказы';
        //$Catalog = new M_Basket(); 
        //$text = $Catalog->showBasketList();
        $text='Здесь скоро будут заказы';
        $this->content = $this->Template('v/v_orders.php', array('text' => $text));	
    }
    

}