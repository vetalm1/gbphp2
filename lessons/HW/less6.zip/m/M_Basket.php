<?php
require_once('m/sql.php');

class M_Basket {  //extends BaseModel

    function showBasketList() {

     $sql = SQL::Instance(); // так подключается синглтон-подключение к БД.
     $req = $sql->Select("SELECT `id_basket`, `user_name`, `id_good`, `good_name`, `price`, `order_id` 
                          FROM test.basket WHERE  `order_id`='' AND user_name= :user_name;", ['user_name'=>$_SESSION['user_name']]);
        
     return $req; //[0]['name'];  //var_dump($req);
    }


}


