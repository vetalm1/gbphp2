<?php
/**
 * Шаблон страницы заказов
 * =======================
 * $text - текст
 */
?>



<?php if ($_SESSION['isAuth'] && $_SESSION['user_name']=='Admin'): ?>






<?else:?>

<h5 class=" m-3 alert alert-danger">Доступ ограничен, авторизуйтесь чтобы продолжить 
<a class="ml-4 " href="index.php?c=users&act=auth">Авторизация</a>
</h5>

<?endif?>