<?php
/**
 * Øàáëîí ðåäàêòîðà
 * ================
 * $text - òåêñò ñòàòüè
 */
?>

<form method="post">
	<textarea name="text"><?=$text?></textarea>
	<br/>
	<input type="submit" value="Сохранить" />
</form>
